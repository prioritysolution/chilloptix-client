import Navbar from "@/components/navbar";
import { FC } from "react";

interface NavbarContainerProps {}

const NavbarContainer: FC<NavbarContainerProps> = ({}) => {
  return <Navbar />;
};
export default NavbarContainer;
