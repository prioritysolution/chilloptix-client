"use client";

import LoginContainer from "@/container/auth/login";

const LoginPage = () => {
  return <LoginContainer />;
};
export default LoginPage;
