"use client";

const DashboardPage = () => {
  return <div>DashboardPage</div>;
};
export default DashboardPage;
