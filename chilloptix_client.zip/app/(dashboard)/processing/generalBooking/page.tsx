"use client";

import GeneralBookingContainer from "@/container/processing/generalBooking";

const GeneralBookingPage = () => {
  return <GeneralBookingContainer />;
};
export default GeneralBookingPage;
