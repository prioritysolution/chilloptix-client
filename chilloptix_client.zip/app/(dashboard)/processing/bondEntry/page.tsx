"use client";

import BondEntryContainer from "@/container/processing/bondEntry";

const BondEntryPage = () => {
  return <BondEntryContainer />;
};
export default BondEntryPage;
