"use client";

import RackPostingContainer from "@/container/processing/rackPosting";

const RackPostingPage = () => {
  return <RackPostingContainer />;
};
export default RackPostingPage;
