"use client";

import BankAccountContainer from "@/container/master/bankAccount";

const BankAccountPage = () => {
  return <BankAccountContainer />;
};
export default BankAccountPage;
