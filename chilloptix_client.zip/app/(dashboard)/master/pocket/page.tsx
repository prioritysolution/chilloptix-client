"use client";

import PocketContainer from "@/container/master/pocket";

const PocketPage = () => {
  return <PocketContainer />;
};
export default PocketPage;
