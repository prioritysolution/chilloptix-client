"use client";

import AgentContainer from "@/container/master/agent";

const AgentPage = () => {
  return <AgentContainer />;
};
export default AgentPage;
