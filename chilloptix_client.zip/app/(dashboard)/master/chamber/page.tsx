"use client";

import ChamberContainer from "@/container/master/chamber";

const ChamberPage = () => {
  return <ChamberContainer />;
};
export default ChamberPage;
