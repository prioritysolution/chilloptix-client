"use client";

import RackContainer from "@/container/master/rack";

const RackPage = () => {
  return <RackContainer />;
};
export default RackPage;
