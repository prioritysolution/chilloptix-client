"use client";

import FloorContainer from "@/container/master/floor";

const FloorPage = () => {
  return <FloorContainer />;
};
export default FloorPage;
