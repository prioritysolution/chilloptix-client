"use client";

import RentContainer from "@/container/master/rent";

const RentPage = () => {
  return <RentContainer />;
};
export default RentPage;
